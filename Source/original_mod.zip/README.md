# TraderDismissal

Dismiss traders with the click of a button. Simply get rid of loitering traders that have overstayed their welcome with the click of a button.

GitHub: https://github.com/Mehni/TraderDismissal/releases  
Ludeon: https://ludeon.com/forums/index.php?topic=35832.0  
Steam: https://steamcommunity.com/sharedfiles/filedetails/?id=1322328003  

German translation by Quadrum.

Want to donate a translation in your language? Please drop me a link!